'use strict';
// Verify that X-Forwarded-Proto cannot bypass production HTTPS enforcement unless
// the immediate TCP peer is explicitly configured as a trusted proxy.
const {spawn}=require('child_process');
const fs=require('fs');
const os=require('os');
const path=require('path');
const net=require('net');
const assert=require('assert/strict');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function launch(port,data,trustProxyIps){
  const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,NODE_ENV:'production',REQUIRE_HTTPS:'1',TRUST_PROXY:'1',TRUST_PROXY_IPS:trustProxyIps,DEV_CODE:'Sirius-v15-ProxY-9F7q2Xw8-mR4zL6p-SECURE'},stdio:['ignore','ignore','pipe']});
  let logs='';child.stderr.on('data',d=>logs+=d.toString());
  const url=`http://127.0.0.1:${port}/api/ping`;let response=null;
  for(let i=0;i<80;i++){try{response=await fetch(url,{headers:{'x-forwarded-proto':'https'}});if(response.status===426||response.status===200)break}catch{}await wait(100)}
  return {child,logs,url,response};
}
async function stop(child){child.kill('SIGTERM');await Promise.race([new Promise(r=>child.once('exit',r)),wait(2000)])}
async function run(){
  const data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-proxy-'));
  let port=await freePort(),s=await launch(port,path.join(data,'untrusted'),'');
  try{
    assert.equal(s.response?.status,426,'server did not start or accepted forged X-Forwarded-Proto: '+s.logs);
    const r=await fetch(s.url,{headers:{'x-forwarded-proto':'https','x-forwarded-for':'203.0.113.10'}});
    assert.equal(r.status,426,'untrusted direct client bypassed HTTPS enforcement with forwarded headers');
  }finally{await stop(s.child)}
  port=await freePort();s=await launch(port,path.join(data,'trusted'),'127.0.0.1/32');
  try{
    assert.equal(s.response?.status,200,'explicitly allowlisted proxy could not signal HTTPS: '+s.logs);
    console.log('PASS: forwarded HTTPS is ignored from untrusted peers and accepted only from an allowlisted proxy');
  }finally{await stop(s.child);try{fs.rmSync(data,{recursive:true,force:true})}catch{}}
}
run().catch(e=>{console.error(e);process.exitCode=1});
