'use strict';
// Regression guards for fail-closed peer identity verification in the browser client.
const fs=require('fs');
const assert=require('node:assert/strict');
const html=fs.readFileSync(require('node:path').join(__dirname,'index.html'),'utf8');
const send=html.slice(html.indexOf('const sy=async'),html.indexOf('const delMsg=',html.indexOf('const sy=async')));
assert(send.includes("if(!pinned){toast('Отправка заблокирована: сначала сверьте код безопасности собеседника.');seccode(+peerS);return}"),'first-contact sending must fail closed until key verification');
assert(send.includes("else if(pinned!==pk){toast('ОТПРАВКА ЗАБЛОКИРОВАНА: ключ собеседника изменился."),'key changes must block outgoing messages');
assert(!send.includes("LSS(pinName,pk)"),'first contact must not silently pin an unverified key');
const receive=html.slice(html.indexOf('async function takeMsg'),html.indexOf('const rd=',html.indexOf('async function takeMsg')));
assert(receive.includes("if(!pinned||pinned!==pk)throw new Error(!pinned?'unverified-key':'changed-key')"),'incoming E2E messages must not decrypt from unverified or changed keys');
assert(receive.includes('Сообщение скрыто: сначала сверьте код безопасности собеседника'),'unverified incoming messages must be visibly withheld');
console.log('PASS: first-contact key verification is fail-closed for send and receive; changed keys block decryption');
