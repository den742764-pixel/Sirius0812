'use strict';
// Integration regression: sessions inactive for more than a year expire after restart and cannot be revived.
const {spawn}=require('child_process');
const fs=require('fs'),os=require('os'),path=require('path'),net=require('net'),assert=require('assert/strict'),crypto=require('crypto');
const ecdh=crypto.createECDH('prime256v1');ecdh.generateKeys();const pub=ecdh.getPublicKey();
const validPk=JSON.stringify({kty:'EC',crv:'P-256',x:pub.subarray(1,33).toString('base64url'),y:pub.subarray(33,65).toString('base64url'),ext:true,key_ops:[]});
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function start(port,data){const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,TRUST_PROXY:'0',DEV_CODE:'test-only-secret-that-is-longer-than-32-chars'},stdio:['ignore','ignore','pipe']});let logs='';child.stderr.on('data',d=>logs+=d.toString());const base=`http://127.0.0.1:${port}/api/`;let ready=false;for(let i=0;i<80;i++){try{if((await fetch(base+'ping')).ok){ready=true;break}}catch{}await wait(100)}assert(ready,'server did not start: '+logs);return{child,base,logs:()=>logs}}
async function stop(child){child.kill('SIGTERM');await Promise.race([new Promise(r=>child.once('exit',r)),wait(1500)])}
async function post(base,route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return{status:r.status,body:await r.json()}}
async function main(){const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-idle-'));let child;
try{let srv=await start(port,data);child=srv.child;const token=crypto.randomBytes(32).toString('hex');
const reg=await post(srv.base,'auth/register',{token,name:'IdleTest',un:'idle_test',pk:validPk,seen:Date.now(),salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});assert.equal(reg.status,200,'registration failed');const uid=reg.body.uid;
let r=await post(srv.base,'w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{bio:'active'}});assert.equal(r.status,200,'fresh session rejected');await wait(800);await stop(child);child=null;
const dbPath=path.join(data,'db.json'),db=JSON.parse(fs.readFileSync(dbPath,'utf8'));assert(db.tokenMeta&&db.tokenMeta[uid],'session metadata missing');db.tokenMeta[uid].last=Date.now()-366*24*60*60*1000;db.tokenMeta[uid].exp=Date.now()-1000;fs.writeFileSync(dbPath,JSON.stringify(db),{mode:0o600});
srv=await start(port,data);child=srv.child;r=await post(srv.base,'w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{bio:'inactive token must fail'}});assert.equal(r.status,401,'idle-expired token was accepted');
console.log('PASS: session idle for over one year expires after restart and old token is revoked');
}finally{if(child)await stop(child);fs.rmSync(data,{recursive:true,force:true})}}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});
