'use strict';
// Exercises the actual E2E v2 functions extracted from index.html with Node WebCrypto.
const fs=require('fs');
const vm=require('vm');
const {webcrypto}=require('crypto');
const assert=require('assert/strict');
const html=fs.readFileSync(require('path').join(__dirname,'index.html'),'utf8');
const start=html.indexOf('const msgAAD=');
const end=html.indexOf('async function kdf(',start);
assert(start>=0&&end>start,'E2E v2 implementation was not found in index.html');
const implementation=html.slice(start,end);
const harness=`
const crypto=globalThis.crypto;
const te=new TextEncoder(),td=new TextDecoder(),cs=crypto.subtle;
const b64=a=>{a=new Uint8Array(a);let s='';for(let i=0;i<a.length;i+=8192)s+=String.fromCharCode.apply(null,a.subarray(i,i+8192));return btoa(s)};
const ub64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
let PRIV=null;
${implementation}
(async()=>{
 const a=await cs.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);
 const b=await cs.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);
 const aPriv=await cs.exportKey('jwk',a.privateKey),aPub=JSON.stringify(await cs.exportKey('jwk',a.publicKey));
 const bPriv=await cs.exportKey('jwk',b.privateKey),bPub=JSON.stringify(await cs.exportKey('jwk',b.publicKey));
 const payload={k:'t',t:'sirius crypto regression',tm:'12:34',rp:0};
 const aad=msgAAD('10000001_10000002','10000001','10000002','msg-1',1700000000000);
 PRIV=aPriv;const sealed1=await sealMsg(bPub,payload,aad);const sealed2=await sealMsg(bPub,payload,aad);
 if(sealed1===sealed2)throw new Error('same plaintext reused the same envelope');
 PRIV=bPriv;const opened=await openMsg(aPub,sealed1,aad);
 if(JSON.stringify(opened)!==JSON.stringify(payload))throw new Error('recipient failed to decrypt valid message');
 let rejected=false;try{await openMsg(aPub,sealed1,msgAAD('10000001_10000002','10000001','10000002','different-id',1700000000000))}catch(e){rejected=true}
 if(!rejected)throw new Error('message ID substitution was not detected');
 rejected=false;try{await openMsg(aPub,sealed1,msgAAD('10000001_10000002','10000001','99999999','msg-1',1700000000000))}catch(e){rejected=true}
 if(!rejected)throw new Error('recipient substitution was not detected');
 const e=JSON.parse(new TextDecoder().decode(ub64(sealed1)));const ct=ub64(e.c);ct[0]^=1;e.c=b64(ct);rejected=false;try{await openMsg(aPub,b64(new TextEncoder().encode(JSON.stringify(e))),aad)}catch(err){rejected=true}
 if(!rejected)throw new Error('ciphertext tampering was not detected');
 return 'PASS: E2E v2 sender/recipient round-trip, fresh envelopes, metadata binding and tamper rejection';
})()`;
const context={crypto:webcrypto,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,JSON,Error,Promise,console,btoa,atob};
vm.createContext(context);
const result=vm.runInContext(harness,context,{timeout:10000});
result.then(x=>console.log(x)).catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});
